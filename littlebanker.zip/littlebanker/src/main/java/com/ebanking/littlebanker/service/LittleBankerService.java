package com.ebanking.littlebanker.service;

public interface LittleBankerService {

	
	public String getMessage();
}
