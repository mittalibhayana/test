package com.ebanking.littlebanker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LittlebankerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LittlebankerApplication.class, args);
	}

}
